<?php
$host = 'localhost';
$db = 'bsitwfbl_student_pre_enrollment'; // full DB name including prefix
$user = 'bsitwfbl_yowdyz';               // full DB user including prefix
$pass = 'AZdJAwXRwAcr8hk';               // your password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
